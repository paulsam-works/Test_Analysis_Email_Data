import json
from PIL import Image, ImageDraw, ImageFont
import os

# Load JSON
root = os.path.dirname(__file__)
with open(os.path.join(root, 'transform_gem.json')) as f:
    data = json.load(f)

# Simple layout parameters
W, H = 1400, 900
bg = (255,255,255)
img = Image.new('RGB', (W, H), bg)
d = ImageDraw.Draw(img)

try:
    font = ImageFont.truetype('arial.ttf', 14)
    font_small = ImageFont.truetype('arial.ttf', 12)
except:
    font = ImageFont.load_default()
    font_small = ImageFont.load_default()

# Helper to draw rounded rectangle
def rounded_rect(draw, xy, radius, fill, outline):
    x0,y0,x1,y1 = xy
    draw.rectangle([x0+radius, y0, x1-radius, y1], fill=fill)
    draw.rectangle([x0, y0+radius, x1, y1-radius], fill=fill)
    draw.pieslice([x0, y0, x0+2*radius, y0+2*radius], 180, 270, fill=fill)
    draw.pieslice([x1-2*radius, y0, x1, y0+2*radius], 270, 360, fill=fill)
    draw.pieslice([x0, y1-2*radius, x0+2*radius, y1], 90, 180, fill=fill)
    draw.pieslice([x1-2*radius, y1-2*radius, x1, y1], 0, 90, fill=fill)
    # outline
    draw.rounded_rectangle([x0,y0,x1,y1], radius=radius, outline=outline, width=2)

# Define node positions
nodes = {
    's3': (60, 110, 280, 170),
    'copy': (300, 90, 540, 190),
    'stage': (560, 110, 800, 170),
    'count': (820, 90, 1060, 190),
    'delete': (1080, 190, 1320, 260),
    'insert': (1080, 290, 1320, 360),
    'sales': (1340, 250, 1560, 320),
    'error': (980, 10, 1220, 80),
    'maintenance': (1160, 380, 1480, 500),
}

# Colors
colors = {
    'src': (248,249,250),
    'op': (255,247,237),
    'tgt': (240,255,244),
    'ctl': (255,255,255),
    'err': (255,238,238)
}

# Draw nodes
rounded_rect(d, nodes['s3'], 8, colors['src'], (43,108,176))
d.text(((nodes['s3'][0]+nodes['s3'][2])//2 - 70, nodes['s3'][1]+15), 'S3\n(s3://my-bucket/data/)\nPARQUET (MANIFEST)', fill=(17,24,39), font=font)

rounded_rect(d, nodes['copy'], 8, colors['op'], (214,158,46))
d.text(((nodes['copy'][0]+nodes['copy'][2])//2 - 40, nodes['copy'][1]+15), 'COPY\n(parquet manifest)', fill=(17,24,39), font=font)

rounded_rect(d, nodes['stage'], 8, colors['op'], (214,158,46))
d.text(((nodes['stage'][0]+nodes['stage'][2])//2 - 70, nodes['stage'][1]+15), 'stage_sales_events\nTEMP TABLE (LIKE sales_events)', fill=(17,24,39), font=font_small)

rounded_rect(d, nodes['count'], 8, colors['ctl'], (107,114,128))
d.text(((nodes['count'][0]+nodes['count'][2])//2 - 60, nodes['count'][1]+15), 'SELECT COUNT(*)\n(row_count)', fill=(17,24,39), font=font)

rounded_rect(d, nodes['delete'], 8, colors['op'], (214,158,46))
d.text(((nodes['delete'][0]+nodes['delete'][2])//2 - 80, nodes['delete'][1]+15), 'DELETE\n(sales_events USING stage)', fill=(17,24,39), font=font_small)

rounded_rect(d, nodes['insert'], 8, colors['op'], (214,158,46))
d.text(((nodes['insert'][0]+nodes['insert'][2])//2 - 70, nodes['insert'][1]+15), 'INSERT\n(INTO sales_events SELECT * FROM stage)', fill=(17,24,39), font=font_small)

rounded_rect(d, nodes['sales'], 8, colors['tgt'], (47,133,90))
d.text(((nodes['sales'][0]+nodes['sales'][2])//2 - 60, nodes['sales'][1]+25), 'sales_events\nTarget table\n(has sales_id)', fill=(17,24,39), font=font_small)

rounded_rect(d, nodes['error'], 8, colors['err'], (185,28,28))
d.text(((nodes['error'][0]+nodes['error'][2])//2 - 60, nodes['error'][1]+15), 'ERROR / ROLLBACK\n(row_count == 0)\nEXIT 1', fill=(17,24,39), font=font_small)

rounded_rect(d, nodes['maintenance'], 8, colors['ctl'], (156,163,175))
d.text(((nodes['maintenance'][0]+nodes['maintenance'][2])//2 - 140, nodes['maintenance'][1]+15), 'Maintenance\nIf row_count > 1,000,000 -> VACUUM DELETE ONLY\nFinally: ANALYZE sales_events', fill=(17,24,39), font=font_small)

# Draw arrows (simple lines with triangles)
def draw_arrow(draw, x1,y1,x2,y2, color=(0,0,0)):
    draw.line((x1,y1,x2,y2), fill=color, width=3)
    # simple arrowhead
    import math
    angle = math.atan2(y2-y1, x2-x1)
    arrow_length = 12
    left = (x2 - arrow_length*math.cos(angle - math.pi/6), y2 - arrow_length*math.sin(angle - math.pi/6))
    right = (x2 - arrow_length*math.cos(angle + math.pi/6), y2 - arrow_length*math.sin(angle + math.pi/6))
    draw.polygon([ (x2,y2), left, right ], fill=color)

# calculate centers
def center(rect):
    x0,y0,x1,y1 = rect
    return ((x0+x1)//2, (y0+y1)//2)

# edges
draw_arrow(d, center(nodes['s3'])[0]+60, center(nodes['s3'])[1], center(nodes['copy'])[0]-60, center(nodes['copy'])[1])
draw_arrow(d, center(nodes['copy'])[0]+60, center(nodes['copy'])[1], center(nodes['stage'])[0]-60, center(nodes['stage'])[1])
draw_arrow(d, center(nodes['stage'])[0]+60, center(nodes['stage'])[1], center(nodes['count'])[0]-60, center(nodes['count'])[1])
draw_arrow(d, center(nodes['count'])[0]+60, center(nodes['count'])[1], center(nodes['delete'])[0]-60, center(nodes['delete'])[1])
draw_arrow(d, center(nodes['delete'])[0]+60, center(nodes['delete'])[1], center(nodes['insert'])[0], center(nodes['insert'])[1]-10)
# insert -> sales (right)
draw_arrow(d, center(nodes['insert'])[0]+60, center(nodes['insert'])[1], center(nodes['sales'])[0]-60, center(nodes['sales'])[1])
# count -> error
draw_arrow(d, center(nodes['count'])[0], nodes['count'][1]-10, center(nodes['error'])[0], nodes['error'][3]+10, color=(185,28,28))
# count -> maintenance (down-right)
draw_arrow(d, center(nodes['count'])[0]+40, center(nodes['count'])[1]+40, nodes['maintenance'][0], nodes['maintenance'][1]+20, color=(100,100,100))
# vac -> analyze: draw small connector inside maintenance region
# transaction annotation
bbox = (260,60,1320,420)
d.rectangle(bbox, outline=(107,114,128), width=2)
d.text((270,70), 'Transaction: BEGIN ... COMMIT', fill=(107,114,128), font=font_small)

# Footer note
note = 'Note: layout simplified — see transform_gem.json for full details; column-level mapping unavailable due to SELECT *'
d.text((W//2 - 360, H-30), note, fill=(75,85,99), font=font_small)

# Save PNG
out = os.path.join(root, 'transform_gem.png')
img.save(out)
print('Saved', out)
