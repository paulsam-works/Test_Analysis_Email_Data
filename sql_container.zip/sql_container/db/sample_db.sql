-- High Complexity RSQL ETL Script Example
\set ON_ERROR_STOP on
\set v_date '\'2026-02-20\''
\set v_iam_role '\'arn:aws:iam::123456789012:role/RedshiftS3Role\''
\set v_s3_path '\'s3://my-bucket/data/\''

\echo 'Starting ELT Process for ' :v_date

BEGIN;

-- 1. Create Temporary Staging Table (Dynamic)
CREATE TEMP TABLE stage_sales_events (LIKE sales_events);

-- 2. Load Data from S3 using Manifest (High Complexity)
COPY stage_sales_events
FROM :v_s3_path
IAM_ROLE :v_iam_role
FORMAT AS PARQUET
MANIFEST
TIMEFORMAT 'auto';

-- 3. Error Handling: Check if data was loaded
SELECT COUNT(*) as row_count FROM stage_sales_events \gset
\if :row_count == 0
    \echo 'Error: No data loaded. Aborting.'
    ROLLBACK;
    \exit 1
\endif

-- 4. Merge Data (Upsert) - Deleting matched existing records
DELETE FROM sales_events
USING stage_sales_events
WHERE sales_events.sales_id = stage_sales_events.sales_id;

-- 5. Insert New Data
INSERT INTO sales_events
SELECT * FROM stage_sales_events;

COMMIT;

-- 6. Conditional Maintenance (Complex Logic)
\if :row_count > 1000000
    \echo 'Large volume detected, running deep table optimization'
    VACUUM DELETE ONLY sales_events;
    ANALYZE sales_events;
\else
    \echo 'Small volume, running ANALYZE only'
    ANALYZE sales_events;
\endif

\echo 'ETL Complete. Rows processed: ' :row_count
\exit 0
